//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by binhex.rc
//
#define IDB_INCSEARCH                   101
#define IDB_MOVEVIEW                    102
#define IDB_BITMAP3                     103

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
